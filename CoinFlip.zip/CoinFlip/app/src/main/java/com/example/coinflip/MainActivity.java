package com.example.coinflip;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.strictmode.NetworkViolation;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {


    Button b_flip;
     ImageView iv_coin;

    Random r;

    int coinside; //0-heads 1-tails


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b_flip = (Button) findViewById(R.id.b_flip);

        iv_coin =(ImageView) findViewById(R.id.iv_coin);

        r= new Random();

        b_flip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                coinside = (int) (Math.random() * 2) + 1;

                if(coinside==1)
                {
                    iv_coin.setImageResource(R.drawable.glava);
                }
                else
                {
                    iv_coin.setImageResource(R.drawable.slika);
                }

                RotateAnimation rotate = new RotateAnimation(0,360,RotateAnimation.RELATIVE_TO_SELF, 0.5f,  RotateAnimation.RELATIVE_TO_SELF, 0.5f);

                rotate.setDuration(1000);
                iv_coin.startAnimation(rotate);
            }
        });



    }

    private class Random {
    }
}