package com.example.coinflip;

public class Radnom {
}
